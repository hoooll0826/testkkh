examples
--------

No examples are currently available. See the `CircuitPython docs
<https://circuitpython.readthedocs.io/>`_ for extensive API documentation.
