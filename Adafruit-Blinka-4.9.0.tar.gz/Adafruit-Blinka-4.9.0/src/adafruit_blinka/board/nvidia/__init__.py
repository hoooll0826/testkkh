"""Boards definition from NVIDIA"""
